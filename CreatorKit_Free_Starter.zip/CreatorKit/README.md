# CreatorKit — Free YouTube Creator Toolkit

A beginner-friendly static website that generates YouTube title ideas, descriptions, hashtags and thumbnail text.

## Important
This starter version uses built-in templates, not a paid AI model/API. It is free to run and works in the browser. It is an AI-toolkit-style starter, but outputs are template-generated rather than genuine AI responses.

## Publish free with GitHub Pages
1. Create a GitHub repository (or use a repository you own and have permission to edit).
2. Upload `index.html` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The Pages screen will show the live URL.

## Customise
- Change the site name by editing `CreatorKit` in `index.html`.
- Update colours in the `:root` CSS section.
- Add more tools by creating new sections and JavaScript functions.

## Next improvements
- Add an AI API only after checking its pricing, free limits, privacy terms and age/account requirements.
- Add a privacy policy before collecting user data.
- Do not promise that generated titles or hashtags guarantee views.
